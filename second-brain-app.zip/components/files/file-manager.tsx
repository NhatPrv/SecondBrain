"use client"

import { useMemo, useRef, useState } from "react"
import {
  Folder,
  FolderOpen,
  ChevronRight,
  Upload,
  Search,
  Grid2x2,
  List,
  MoreVertical,
  Pencil,
  FolderInput,
  Trash2,
  Star,
  Download,
  Home,
  Plus,
  FileUp,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { cn } from "@/lib/utils"
import { initialItems, type DriveItem } from "@/lib/files-data"
import { kindMeta } from "@/components/files/file-icon"

export function FileManager() {
  const [items, setItems] = useState<DriveItem[]>(initialItems)
  const [currentFolder, setCurrentFolder] = useState<string | null>(null)
  const [query, setQuery] = useState("")
  const [view, setView] = useState<"grid" | "list">("grid")
  const [dragOver, setDragOver] = useState(false)
  const [draggingId, setDraggingId] = useState<string | null>(null)
  const [renaming, setRenaming] = useState<DriveItem | null>(null)
  const [renameValue, setRenameValue] = useState("")
  const [moving, setMoving] = useState<DriveItem | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const folders = items.filter((i) => i.kind === "folder")

  const breadcrumbs = useMemo(() => {
    const chain: DriveItem[] = []
    let id = currentFolder
    while (id) {
      const f = items.find((i) => i.id === id)
      if (!f) break
      chain.unshift(f)
      id = f.parentId
    }
    return chain
  }, [currentFolder, items])

  const visible = useMemo(() => {
    let list = items.filter((i) => i.parentId === currentFolder)
    if (query.trim()) {
      list = items.filter((i) =>
        i.name.toLowerCase().includes(query.toLowerCase()),
      )
    }
    // folders first
    return [...list].sort((a, b) => {
      if (a.kind === "folder" && b.kind !== "folder") return -1
      if (a.kind !== "folder" && b.kind === "folder") return 1
      return a.name.localeCompare(b.name)
    })
  }, [items, currentFolder, query])

  function addUploads(files: FileList | File[]) {
    const arr = Array.from(files)
    if (arr.length === 0) return
    const newItems: DriveItem[] = arr.map((f, idx) => ({
      id: `up-${Date.now()}-${idx}`,
      name: f.name,
      kind: guessKind(f.name),
      size: formatSize(f.size),
      modified: "Just now",
      parentId: currentFolder,
    }))
    setItems((prev) => [...prev, ...newItems])
  }

  function deleteItem(id: string) {
    setItems((prev) => prev.filter((i) => i.id !== id && i.parentId !== id))
  }

  function toggleStar(id: string) {
    setItems((prev) =>
      prev.map((i) => (i.id === id ? { ...i, starred: !i.starred } : i)),
    )
  }

  function commitRename() {
    if (!renaming || !renameValue.trim()) return
    setItems((prev) =>
      prev.map((i) =>
        i.id === renaming.id ? { ...i, name: renameValue.trim() } : i,
      ),
    )
    setRenaming(null)
  }

  function moveItem(itemId: string, targetFolderId: string | null) {
    if (itemId === targetFolderId) return
    setItems((prev) =>
      prev.map((i) =>
        i.id === itemId ? { ...i, parentId: targetFolderId } : i,
      ),
    )
  }

  function newFolder() {
    setItems((prev) => [
      ...prev,
      {
        id: `nf-${Date.now()}`,
        name: "Untitled folder",
        kind: "folder",
        modified: "Just now",
        parentId: currentFolder,
      },
    ])
  }

  return (
    <div className="flex h-full">
      {/* Folder tree */}
      <div className="hidden w-64 shrink-0 flex-col border-r border-border lg:flex">
        <div className="p-3">
          <Button className="w-full gap-2" onClick={() => fileInputRef.current?.click()}>
            <Upload className="size-4" />
            Upload
          </Button>
        </div>
        <ScrollArea className="flex-1 px-2">
          <button
            onClick={() => setCurrentFolder(null)}
            className={cn(
              "flex w-full items-center gap-2 rounded-md px-3 py-2 text-sm transition-colors",
              currentFolder === null
                ? "bg-accent font-medium text-accent-foreground"
                : "text-muted-foreground hover:bg-accent/50",
            )}
          >
            <Home className="size-4" />
            My Drive
          </button>
          <FolderTree
            folders={folders}
            parentId={null}
            currentFolder={currentFolder}
            onSelect={setCurrentFolder}
            depth={0}
            onDropItem={moveItem}
            draggingId={draggingId}
          />
        </ScrollArea>
        <div className="border-t border-border p-3">
          <div className="mb-1 flex items-center justify-between text-xs text-muted-foreground">
            <span>Storage</span>
            <span>4.2 GB of 15 GB</span>
          </div>
          <div className="h-1.5 w-full overflow-hidden rounded-full bg-muted">
            <div className="h-full w-[28%] rounded-full bg-primary" />
          </div>
        </div>
      </div>

      {/* Main */}
      <div className="flex min-w-0 flex-1 flex-col">
        {/* Toolbar */}
        <div className="flex flex-wrap items-center gap-2 border-b border-border px-4 py-3">
          <div className="flex min-w-0 flex-1 items-center gap-1 text-sm">
            <button
              onClick={() => setCurrentFolder(null)}
              className="rounded px-1.5 py-0.5 font-medium hover:bg-accent"
            >
              My Drive
            </button>
            {breadcrumbs.map((b) => (
              <span key={b.id} className="flex items-center gap-1">
                <ChevronRight className="size-4 text-muted-foreground" />
                <button
                  onClick={() => setCurrentFolder(b.id)}
                  className="truncate rounded px-1.5 py-0.5 font-medium hover:bg-accent"
                >
                  {b.name}
                </button>
              </span>
            ))}
          </div>

          <div className="relative w-full sm:w-56">
            <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search files..."
              className="h-9 bg-muted/60 pl-9"
            />
          </div>

          <Button variant="outline" size="sm" className="gap-1.5" onClick={newFolder}>
            <Plus className="size-4" />
            <span className="hidden sm:inline">New folder</span>
          </Button>

          <div className="flex items-center rounded-md border border-border p-0.5">
            <Button
              variant={view === "grid" ? "secondary" : "ghost"}
              size="icon"
              className="size-7"
              aria-label="Grid view"
              onClick={() => setView("grid")}
            >
              <Grid2x2 className="size-4" />
            </Button>
            <Button
              variant={view === "list" ? "secondary" : "ghost"}
              size="icon"
              className="size-7"
              aria-label="List view"
              onClick={() => setView("list")}
            >
              <List className="size-4" />
            </Button>
          </div>
        </div>

        {/* Drop zone / content */}
        <div
          className="relative flex-1 overflow-y-auto p-4"
          onDragOver={(e) => {
            e.preventDefault()
            if (!draggingId) setDragOver(true)
          }}
          onDragLeave={(e) => {
            if (e.currentTarget === e.target) setDragOver(false)
          }}
          onDrop={(e) => {
            e.preventDefault()
            setDragOver(false)
            if (e.dataTransfer.files.length) addUploads(e.dataTransfer.files)
          }}
        >
          {dragOver && (
            <div className="pointer-events-none absolute inset-3 z-20 flex flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed border-primary bg-primary/5">
              <FileUp className="size-8 text-primary" />
              <p className="text-sm font-medium text-primary">
                Drop files to upload
              </p>
            </div>
          )}

          {visible.length === 0 ? (
            <div className="flex h-full flex-col items-center justify-center gap-3 text-center">
              <div className="flex size-14 items-center justify-center rounded-full bg-muted">
                <FolderOpen className="size-7 text-muted-foreground" />
              </div>
              <div>
                <p className="text-sm font-medium">
                  {query ? "No files match your search" : "This folder is empty"}
                </p>
                <p className="text-xs text-muted-foreground">
                  Drag files here or use the upload button
                </p>
              </div>
            </div>
          ) : view === "grid" ? (
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">
              {visible.map((item) => (
                <GridCard
                  key={item.id}
                  item={item}
                  onOpen={() =>
                    item.kind === "folder" && setCurrentFolder(item.id)
                  }
                  onRename={() => {
                    setRenaming(item)
                    setRenameValue(item.name)
                  }}
                  onMove={() => setMoving(item)}
                  onDelete={() => deleteItem(item.id)}
                  onStar={() => toggleStar(item.id)}
                  onDragStart={() => setDraggingId(item.id)}
                  onDragEnd={() => setDraggingId(null)}
                  onDropOnFolder={() => {
                    if (item.kind === "folder" && draggingId)
                      moveItem(draggingId, item.id)
                  }}
                  isDragging={draggingId === item.id}
                />
              ))}
            </div>
          ) : (
            <div className="overflow-hidden rounded-lg border border-border">
              <div className="grid grid-cols-[1fr_auto_auto_auto] items-center gap-4 border-b border-border bg-muted/40 px-4 py-2 text-xs font-medium text-muted-foreground">
                <span>Name</span>
                <span className="hidden sm:block">Type</span>
                <span className="hidden w-20 sm:block">Size</span>
                <span className="w-8" />
              </div>
              {visible.map((item) => (
                <ListRow
                  key={item.id}
                  item={item}
                  onOpen={() =>
                    item.kind === "folder" && setCurrentFolder(item.id)
                  }
                  onRename={() => {
                    setRenaming(item)
                    setRenameValue(item.name)
                  }}
                  onMove={() => setMoving(item)}
                  onDelete={() => deleteItem(item.id)}
                  onStar={() => toggleStar(item.id)}
                />
              ))}
            </div>
          )}
        </div>
      </div>

      {/* hidden file input */}
      <input
        ref={fileInputRef}
        type="file"
        multiple
        className="hidden"
        onChange={(e) => {
          if (e.target.files) addUploads(e.target.files)
          e.target.value = ""
        }}
      />

      {/* Rename dialog */}
      <Dialog open={!!renaming} onOpenChange={(o) => !o && setRenaming(null)}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>Rename</DialogTitle>
          </DialogHeader>
          <Input
            autoFocus
            value={renameValue}
            onChange={(e) => setRenameValue(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && commitRename()}
          />
          <DialogFooter>
            <Button variant="ghost" onClick={() => setRenaming(null)}>
              Cancel
            </Button>
            <Button onClick={commitRename}>Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Move dialog */}
      <Dialog open={!!moving} onOpenChange={(o) => !o && setMoving(null)}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>Move &ldquo;{moving?.name}&rdquo;</DialogTitle>
          </DialogHeader>
          <div className="flex flex-col gap-1">
            <button
              onClick={() => {
                if (moving) moveItem(moving.id, null)
                setMoving(null)
              }}
              className="flex items-center gap-2 rounded-md px-3 py-2 text-sm hover:bg-accent"
            >
              <Home className="size-4 text-muted-foreground" />
              My Drive
            </button>
            {folders
              .filter((f) => f.id !== moving?.id)
              .map((f) => (
                <button
                  key={f.id}
                  onClick={() => {
                    if (moving) moveItem(moving.id, f.id)
                    setMoving(null)
                  }}
                  className="flex items-center gap-2 rounded-md px-3 py-2 text-sm hover:bg-accent"
                >
                  <Folder className="size-4 text-chart-1" />
                  {f.name}
                </button>
              ))}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}

function FolderTree({
  folders,
  parentId,
  currentFolder,
  onSelect,
  depth,
  onDropItem,
  draggingId,
}: {
  folders: DriveItem[]
  parentId: string | null
  currentFolder: string | null
  onSelect: (id: string) => void
  depth: number
  onDropItem: (itemId: string, target: string) => void
  draggingId: string | null
}) {
  const children = folders.filter((f) => f.parentId === parentId)
  if (children.length === 0) return null
  return (
    <div className="flex flex-col">
      {children.map((f) => (
        <div key={f.id}>
          <button
            onClick={() => onSelect(f.id)}
            onDragOver={(e) => draggingId && e.preventDefault()}
            onDrop={() => draggingId && onDropItem(draggingId, f.id)}
            style={{ paddingLeft: 12 + depth * 14 }}
            className={cn(
              "flex w-full items-center gap-2 rounded-md py-2 pr-3 text-sm transition-colors",
              currentFolder === f.id
                ? "bg-accent font-medium text-accent-foreground"
                : "text-muted-foreground hover:bg-accent/50",
            )}
          >
            <Folder className="size-4 shrink-0 text-chart-1" />
            <span className="truncate">{f.name}</span>
          </button>
          <FolderTree
            folders={folders}
            parentId={f.id}
            currentFolder={currentFolder}
            onSelect={onSelect}
            depth={depth + 1}
            onDropItem={onDropItem}
            draggingId={draggingId}
          />
        </div>
      ))}
    </div>
  )
}

function ItemMenu({
  isFolder,
  starred,
  onRename,
  onMove,
  onDelete,
  onStar,
}: {
  isFolder: boolean
  starred?: boolean
  onRename: () => void
  onMove: () => void
  onDelete: () => void
  onStar: () => void
}) {
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          variant="ghost"
          size="icon"
          className="size-7"
          aria-label="More options"
          onClick={(e) => e.stopPropagation()}
        >
          <MoreVertical className="size-4" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" onClick={(e) => e.stopPropagation()}>
        <DropdownMenuItem onClick={onStar}>
          <Star className={cn("size-4", starred && "fill-chart-4 text-chart-4")} />
          {starred ? "Remove star" : "Add star"}
        </DropdownMenuItem>
        <DropdownMenuItem onClick={onRename}>
          <Pencil className="size-4" />
          Rename
        </DropdownMenuItem>
        <DropdownMenuItem onClick={onMove}>
          <FolderInput className="size-4" />
          Move to
        </DropdownMenuItem>
        {!isFolder && (
          <DropdownMenuItem>
            <Download className="size-4" />
            Download
          </DropdownMenuItem>
        )}
        <DropdownMenuSeparator />
        <DropdownMenuItem variant="destructive" onClick={onDelete}>
          <Trash2 className="size-4" />
          Delete
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}

function GridCard({
  item,
  onOpen,
  onRename,
  onMove,
  onDelete,
  onStar,
  onDragStart,
  onDragEnd,
  onDropOnFolder,
  isDragging,
}: {
  item: DriveItem
  onOpen: () => void
  onRename: () => void
  onMove: () => void
  onDelete: () => void
  onStar: () => void
  onDragStart: () => void
  onDragEnd: () => void
  onDropOnFolder: () => void
  isDragging: boolean
}) {
  const meta = kindMeta[item.kind]
  const Icon = meta.icon
  const isFolder = item.kind === "folder"
  return (
    <div
      draggable
      onDragStart={onDragStart}
      onDragEnd={onDragEnd}
      onDragOver={(e) => isFolder && e.preventDefault()}
      onDrop={() => isFolder && onDropOnFolder()}
      onDoubleClick={onOpen}
      className={cn(
        "group relative flex cursor-pointer flex-col rounded-xl border border-border bg-card p-3 transition-all hover:border-primary/40 hover:shadow-sm",
        isDragging && "opacity-40",
      )}
    >
      <div className="absolute right-1.5 top-1.5 opacity-0 transition-opacity group-hover:opacity-100">
        <ItemMenu
          isFolder={isFolder}
          starred={item.starred}
          onRename={onRename}
          onMove={onMove}
          onDelete={onDelete}
          onStar={onStar}
        />
      </div>
      {item.starred && (
        <Star className="absolute left-2 top-2 size-3.5 fill-chart-4 text-chart-4" />
      )}
      <div
        className={cn(
          "mb-3 flex aspect-[4/3] items-center justify-center rounded-lg",
          meta.bg,
        )}
      >
        <Icon className={cn("size-9", meta.tint)} />
      </div>
      <p className="truncate text-sm font-medium">{item.name}</p>
      <p className="mt-0.5 text-xs text-muted-foreground">
        {item.size ? `${item.size} · ` : ""}
        {item.modified}
      </p>
    </div>
  )
}

function ListRow({
  item,
  onOpen,
  onRename,
  onMove,
  onDelete,
  onStar,
}: {
  item: DriveItem
  onOpen: () => void
  onRename: () => void
  onMove: () => void
  onDelete: () => void
  onStar: () => void
}) {
  const meta = kindMeta[item.kind]
  const Icon = meta.icon
  const isFolder = item.kind === "folder"
  return (
    <div
      onDoubleClick={onOpen}
      className="grid cursor-pointer grid-cols-[1fr_auto_auto_auto] items-center gap-4 border-b border-border px-4 py-2.5 text-sm transition-colors last:border-0 hover:bg-accent/40"
    >
      <div className="flex min-w-0 items-center gap-3">
        <span
          className={cn(
            "flex size-8 shrink-0 items-center justify-center rounded-md",
            meta.bg,
          )}
        >
          <Icon className={cn("size-4", meta.tint)} />
        </span>
        <span className="flex items-center gap-1.5 truncate font-medium">
          {item.name}
          {item.starred && (
            <Star className="size-3 shrink-0 fill-chart-4 text-chart-4" />
          )}
        </span>
      </div>
      <span className="hidden text-xs text-muted-foreground sm:block">
        {meta.label}
      </span>
      <span className="hidden w-20 text-xs text-muted-foreground sm:block">
        {item.size ?? "—"}
      </span>
      <ItemMenu
        isFolder={isFolder}
        starred={item.starred}
        onRename={onRename}
        onMove={onMove}
        onDelete={onDelete}
        onStar={onStar}
      />
    </div>
  )
}

function guessKind(name: string): DriveItem["kind"] {
  const ext = name.split(".").pop()?.toLowerCase() ?? ""
  if (["jpg", "jpeg", "png", "gif", "webp", "heic"].includes(ext)) return "image"
  if (ext === "pdf") return "pdf"
  if (["doc", "docx", "txt", "rtf"].includes(ext)) return "doc"
  if (["xls", "xlsx", "csv", "sheet"].includes(ext)) return "sheet"
  if (["mp4", "mov", "webm", "avi"].includes(ext)) return "video"
  if (["mp3", "wav", "m4a", "aac"].includes(ext)) return "audio"
  return "file"
}

function formatSize(bytes: number): string {
  if (!bytes) return "0 KB"
  const kb = bytes / 1024
  if (kb < 1024) return `${Math.max(1, Math.round(kb))} KB`
  return `${(kb / 1024).toFixed(1)} MB`
}
