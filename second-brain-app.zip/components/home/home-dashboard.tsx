import Link from "next/link"
import {
  MessageCircle,
  Users,
  FolderClosed,
  StickyNote,
  Pin,
  FileText,
  ImageIcon,
  ArrowUpRight,
  Clock,
} from "lucide-react"
import { Card } from "@/components/ui/card"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { cn } from "@/lib/utils"
import { family } from "@/lib/data"

const quickLinks = [
  { title: "Self Chat", desc: "Your private notes & ideas", href: "/self-chat", icon: MessageCircle, tint: "text-chart-1" },
  { title: "Family Chat", desc: "3 unread messages", href: "/family-chat", icon: Users, tint: "text-chart-3" },
  { title: "Files", desc: "128 items · 4.2 GB", href: "/files", icon: FolderClosed, tint: "text-chart-4" },
  { title: "Notes", desc: "12 notes · 3 pinned", href: "/notes", icon: StickyNote, tint: "text-chart-5" },
]

const recent = [
  { title: "Summer trip checklist", type: "note", icon: StickyNote, when: "2m ago" },
  { title: "Grocery_receipt.pdf", type: "file", icon: FileText, when: "1h ago" },
  { title: "Beach_house.jpg", type: "image", icon: ImageIcon, when: "3h ago" },
  { title: "Wifi passwords", type: "note", icon: StickyNote, when: "Yesterday" },
]

const pinned = [
  { title: "Emergency contacts", from: "Notes" },
  { title: "House rules", from: "Family Chat" },
  { title: "Passport scans", from: "Files" },
]

export function HomeDashboard() {
  return (
    <div className="mx-auto w-full max-w-6xl px-4 py-6 lg:px-8">
      {/* Greeting */}
      <div className="mb-6">
        <h2 className="text-2xl font-semibold tracking-tight text-balance">
          Good evening, Maya
        </h2>
        <p className="mt-1 text-sm text-muted-foreground">
          Here&apos;s what&apos;s happening in your family workspace today.
        </p>
      </div>

      {/* Quick links */}
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {quickLinks.map((q) => {
          const Icon = q.icon
          return (
            <Link key={q.href} href={q.href}>
              <Card className="group h-full gap-0 p-4 transition-colors hover:border-primary/40 hover:bg-accent/40">
                <div className="mb-3 flex items-center justify-between">
                  <span className="flex size-10 items-center justify-center rounded-lg bg-muted">
                    <Icon className={cn("size-5", q.tint)} />
                  </span>
                  <ArrowUpRight className="size-4 text-muted-foreground opacity-0 transition-opacity group-hover:opacity-100" />
                </div>
                <p className="text-sm font-semibold">{q.title}</p>
                <p className="mt-0.5 text-xs text-muted-foreground">{q.desc}</p>
              </Card>
            </Link>
          )
        })}
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-3">
        {/* Recent activity */}
        <Card className="lg:col-span-2">
          <div className="flex items-center justify-between px-5 pt-5">
            <h3 className="text-sm font-semibold">Recent activity</h3>
            <Clock className="size-4 text-muted-foreground" />
          </div>
          <div className="mt-2 flex flex-col">
            {recent.map((r, i) => {
              const Icon = r.icon
              return (
                <div
                  key={i}
                  className="flex items-center gap-3 px-5 py-3 transition-colors hover:bg-accent/40"
                >
                  <span className="flex size-9 items-center justify-center rounded-md bg-muted">
                    <Icon className="size-[18px] text-muted-foreground" />
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium">{r.title}</p>
                    <p className="text-xs capitalize text-muted-foreground">
                      {r.type}
                    </p>
                  </div>
                  <span className="text-xs text-muted-foreground">{r.when}</span>
                </div>
              )
            })}
          </div>
        </Card>

        {/* Family + pinned */}
        <div className="flex flex-col gap-4">
          <Card className="p-5">
            <h3 className="mb-4 text-sm font-semibold">Family</h3>
            <div className="flex flex-col gap-3">
              {family.map((m) => (
                <div key={m.id} className="flex items-center gap-3">
                  <div className="relative">
                    <Avatar className="size-8">
                      <AvatarFallback className={cn("text-xs text-white", m.color)}>
                        {m.initials}
                      </AvatarFallback>
                    </Avatar>
                    <span
                      className={cn(
                        "absolute -bottom-0.5 -right-0.5 size-3 rounded-full border-2 border-card",
                        m.online ? "bg-chart-3" : "bg-muted-foreground/40",
                      )}
                    />
                  </div>
                  <span className="flex-1 truncate text-sm">{m.name}</span>
                  <span className="text-xs text-muted-foreground">
                    {m.online ? "Online" : "Away"}
                  </span>
                </div>
              ))}
            </div>
          </Card>

          <Card className="p-5">
            <div className="mb-3 flex items-center gap-2">
              <Pin className="size-4 text-primary" />
              <h3 className="text-sm font-semibold">Pinned</h3>
            </div>
            <div className="flex flex-col gap-1">
              {pinned.map((p, i) => (
                <div
                  key={i}
                  className="flex items-center justify-between rounded-md px-2 py-2 text-sm transition-colors hover:bg-accent/40"
                >
                  <span className="truncate">{p.title}</span>
                  <span className="text-xs text-muted-foreground">{p.from}</span>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </div>
  )
}
