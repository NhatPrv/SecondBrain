"use client"

import { useMemo, useRef, useState } from "react"
import {
  Search,
  Send,
  Pin,
  Reply,
  SmilePlus,
  Paperclip,
  Phone,
  Video,
  MoreVertical,
  X,
  ArrowLeft,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import { cn } from "@/lib/utils"
import {
  type ChatMessage,
  type Conversation,
  messagesByConversation,
} from "@/lib/messenger-data"

const REACTIONS = ["👍", "❤️", "😂", "🎉", "🌮"]

export function Messenger({
  conversations,
  heading,
}: {
  conversations: Conversation[]
  heading: string
}) {
  const [activeId, setActiveId] = useState(conversations[0]?.id ?? "")
  const [query, setQuery] = useState("")
  const [showThreadMobile, setShowThreadMobile] = useState(false)

  const active = conversations.find((c) => c.id === activeId)

  const filtered = useMemo(
    () =>
      conversations.filter((c) =>
        c.name.toLowerCase().includes(query.toLowerCase()),
      ),
    [conversations, query],
  )

  return (
    <div className="flex h-full">
      {/* Conversation list */}
      <div
        className={cn(
          "flex w-full flex-col border-r border-border md:w-80 md:shrink-0",
          showThreadMobile && "hidden md:flex",
        )}
      >
        <div className="border-b border-border p-3">
          <p className="mb-2 px-1 text-sm font-semibold">{heading}</p>
          <div className="relative">
            <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search conversations..."
              className="h-9 bg-muted/60 pl-9"
            />
          </div>
        </div>
        <ScrollArea className="flex-1">
          <div className="flex flex-col p-2">
            {filtered.map((c) => (
              <button
                key={c.id}
                onClick={() => {
                  setActiveId(c.id)
                  setShowThreadMobile(true)
                }}
                className={cn(
                  "flex w-full items-center gap-3 rounded-lg p-2.5 text-left transition-colors",
                  c.id === activeId
                    ? "bg-accent"
                    : "hover:bg-accent/50",
                )}
              >
                <div className="relative shrink-0">
                  <Avatar className="size-11">
                    <AvatarFallback className={cn("text-sm text-white", c.color)}>
                      {c.initials}
                    </AvatarFallback>
                  </Avatar>
                  {c.type === "direct" && c.online && (
                    <span className="absolute -bottom-0.5 -right-0.5 size-3 rounded-full border-2 border-background bg-chart-3" />
                  )}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between gap-2">
                    <span className="flex items-center gap-1 truncate text-sm font-medium">
                      {c.pinned && <Pin className="size-3 text-muted-foreground" />}
                      {c.name}
                    </span>
                    <span className="shrink-0 text-xs text-muted-foreground">
                      {c.time}
                    </span>
                  </div>
                  <div className="flex items-center justify-between gap-2">
                    <span
                      className={cn(
                        "truncate text-xs",
                        c.last === "Typing..."
                          ? "text-primary"
                          : "text-muted-foreground",
                      )}
                    >
                      {c.type === "group" && c.members
                        ? `${c.members} members · `
                        : ""}
                      {c.last}
                    </span>
                    {c.unread ? (
                      <Badge className="h-5 min-w-5 justify-center rounded-full bg-primary px-1.5 text-xs text-primary-foreground">
                        {c.unread}
                      </Badge>
                    ) : null}
                  </div>
                </div>
              </button>
            ))}
          </div>
        </ScrollArea>
      </div>

      {/* Thread */}
      <div
        className={cn(
          "flex min-w-0 flex-1 flex-col",
          !showThreadMobile && "hidden md:flex",
        )}
      >
        {active ? (
          <Thread
            conversation={active}
            onBack={() => setShowThreadMobile(false)}
          />
        ) : (
          <div className="flex flex-1 items-center justify-center text-sm text-muted-foreground">
            Select a conversation
          </div>
        )}
      </div>
    </div>
  )
}

function Thread({
  conversation,
  onBack,
}: {
  conversation: Conversation
  onBack: () => void
}) {
  const [messages, setMessages] = useState<ChatMessage[]>(
    messagesByConversation[conversation.id] ?? [],
  )
  const [draft, setDraft] = useState("")
  const [replyTo, setReplyTo] = useState<ChatMessage | null>(null)
  const scrollRef = useRef<HTMLDivElement>(null)

  // reset thread state when conversation changes
  const key = conversation.id
  const lastKey = useRef(key)
  if (lastKey.current !== key) {
    lastKey.current = key
    setMessages(messagesByConversation[key] ?? [])
    setReplyTo(null)
    setDraft("")
  }

  const pinned = messages.find((m) => m.pinned)

  function send() {
    if (!draft.trim()) return
    const time = new Date().toLocaleTimeString([], {
      hour: "2-digit",
      minute: "2-digit",
    })
    setMessages((prev) => [
      ...prev,
      {
        id: `s${Date.now()}`,
        authorId: "maya",
        authorName: "Maya",
        initials: "MC",
        color: "bg-chart-1",
        text: draft.trim(),
        time,
        self: true,
        replyTo: replyTo
          ? { author: replyTo.authorName, text: replyTo.text }
          : undefined,
      },
    ])
    setDraft("")
    setReplyTo(null)
    requestAnimationFrame(() =>
      scrollRef.current?.scrollTo({
        top: scrollRef.current.scrollHeight,
        behavior: "smooth",
      }),
    )
  }

  function toggleReaction(messageId: string, emoji: string) {
    setMessages((prev) =>
      prev.map((m) => {
        if (m.id !== messageId) return m
        const reactions = [...(m.reactions ?? [])]
        const idx = reactions.findIndex((r) => r.emoji === emoji)
        if (idx >= 0) {
          const r = reactions[idx]
          const count = r.reacted ? r.count - 1 : r.count + 1
          if (count <= 0) reactions.splice(idx, 1)
          else reactions[idx] = { ...r, count, reacted: !r.reacted }
        } else {
          reactions.push({ emoji, count: 1, reacted: true })
        }
        return { ...m, reactions }
      }),
    )
  }

  return (
    <div className="flex h-full flex-col">
      {/* Header */}
      <div className="flex items-center gap-3 border-b border-border px-3 py-2.5">
        <Button
          variant="ghost"
          size="icon"
          className="size-9 md:hidden"
          aria-label="Back"
          onClick={onBack}
        >
          <ArrowLeft className="size-5" />
        </Button>
        <Avatar className="size-9">
          <AvatarFallback className={cn("text-sm text-white", conversation.color)}>
            {conversation.initials}
          </AvatarFallback>
        </Avatar>
        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-semibold">{conversation.name}</p>
          <p className="truncate text-xs text-muted-foreground">
            {conversation.type === "group"
              ? `${conversation.members} members`
              : conversation.online
                ? "Online"
                : "Last seen recently"}
          </p>
        </div>
        <Button variant="ghost" size="icon" className="size-9" aria-label="Call">
          <Phone className="size-[18px]" />
        </Button>
        <Button
          variant="ghost"
          size="icon"
          className="size-9"
          aria-label="Video call"
        >
          <Video className="size-[18px]" />
        </Button>
        <Button
          variant="ghost"
          size="icon"
          className="size-9"
          aria-label="More options"
        >
          <MoreVertical className="size-[18px]" />
        </Button>
      </div>

      {/* Pinned banner */}
      {pinned && (
        <div className="flex items-center gap-2 border-b border-border bg-accent/40 px-4 py-2">
          <Pin className="size-3.5 shrink-0 text-primary" />
          <p className="truncate text-xs text-accent-foreground">
            <span className="font-medium">Pinned:</span> {pinned.text}
          </p>
        </div>
      )}

      {/* Messages */}
      <div
        ref={scrollRef}
        className="flex-1 overflow-y-auto px-4 py-4"
        style={{
          backgroundImage:
            "radial-gradient(circle at 1px 1px, var(--border) 1px, transparent 0)",
          backgroundSize: "24px 24px",
        }}
      >
        <div className="mx-auto flex max-w-2xl flex-col gap-3">
          {messages.map((m) => (
            <Bubble
              key={m.id}
              message={m}
              isGroup={conversation.type === "group"}
              onReply={() => setReplyTo(m)}
              onReact={(emoji) => toggleReaction(m.id, emoji)}
            />
          ))}
        </div>
      </div>

      {/* Reply preview */}
      {replyTo && (
        <div className="flex items-center gap-3 border-t border-border bg-muted/40 px-4 py-2">
          <Reply className="size-4 shrink-0 text-primary" />
          <div className="min-w-0 flex-1 border-l-2 border-primary pl-2">
            <p className="text-xs font-medium text-primary">
              Reply to {replyTo.authorName}
            </p>
            <p className="truncate text-xs text-muted-foreground">{replyTo.text}</p>
          </div>
          <Button
            variant="ghost"
            size="icon"
            className="size-7"
            aria-label="Cancel reply"
            onClick={() => setReplyTo(null)}
          >
            <X className="size-4" />
          </Button>
        </div>
      )}

      {/* Input */}
      <div className="border-t border-border bg-background px-4 py-3">
        <div className="mx-auto flex max-w-2xl items-end gap-2">
          <Button
            variant="ghost"
            size="icon"
            className="size-10 shrink-0 text-muted-foreground"
            aria-label="Attach"
          >
            <Paperclip className="size-5" />
          </Button>
          <Input
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault()
                send()
              }
            }}
            placeholder={`Message ${conversation.name}...`}
            className="h-11 flex-1 rounded-full bg-muted/60"
          />
          <Button
            size="icon"
            className="size-10 shrink-0 rounded-full"
            aria-label="Send"
            onClick={send}
          >
            <Send className="size-[18px]" />
          </Button>
        </div>
      </div>
    </div>
  )
}

function Bubble({
  message,
  isGroup,
  onReply,
  onReact,
}: {
  message: ChatMessage
  isGroup: boolean
  onReply: () => void
  onReact: (emoji: string) => void
}) {
  const [pickerOpen, setPickerOpen] = useState(false)
  const self = message.self

  return (
    <div className={cn("group flex gap-2", self ? "justify-end" : "justify-start")}>
      {!self && (
        <Avatar className="mt-auto size-7 shrink-0">
          <AvatarFallback className={cn("text-xs text-white", message.color)}>
            {message.initials}
          </AvatarFallback>
        </Avatar>
      )}

      <div
        className={cn(
          "flex max-w-[78%] flex-col gap-1",
          self ? "items-end" : "items-start",
        )}
      >
        <div className="relative">
          {/* hover actions */}
          <div
            className={cn(
              "absolute -top-3 z-10 flex items-center rounded-full border border-border bg-popover shadow-sm opacity-0 transition-opacity group-hover:opacity-100",
              self ? "left-0 -translate-x-full pr-1" : "right-0 translate-x-full pl-1",
            )}
          >
            <Button
              variant="ghost"
              size="icon"
              className="size-7 text-muted-foreground"
              aria-label="React"
              onClick={() => setPickerOpen((p) => !p)}
            >
              <SmilePlus className="size-4" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="size-7 text-muted-foreground"
              aria-label="Reply"
              onClick={onReply}
            >
              <Reply className="size-4" />
            </Button>
          </div>

          {/* emoji picker */}
          {pickerOpen && (
            <div
              className={cn(
                "absolute -top-12 z-20 flex items-center gap-1 rounded-full border border-border bg-popover px-2 py-1.5 shadow-md",
                self ? "right-0" : "left-0",
              )}
            >
              {REACTIONS.map((emoji) => (
                <button
                  key={emoji}
                  className="rounded-full px-1 text-lg transition-transform hover:scale-125"
                  onClick={() => {
                    onReact(emoji)
                    setPickerOpen(false)
                  }}
                >
                  {emoji}
                </button>
              ))}
            </div>
          )}

          <div
            className={cn(
              "rounded-2xl px-3.5 py-2 text-sm shadow-sm",
              self
                ? "rounded-br-md bg-primary text-primary-foreground"
                : "rounded-bl-md bg-card text-card-foreground",
            )}
          >
            {isGroup && !self && (
              <p
                className={cn(
                  "mb-0.5 text-xs font-semibold",
                  message.color.replace("bg-", "text-"),
                )}
              >
                {message.authorName}
              </p>
            )}
            {message.replyTo && (
              <div
                className={cn(
                  "mb-1.5 rounded-md border-l-2 px-2 py-1",
                  self
                    ? "border-primary-foreground/60 bg-primary-foreground/15"
                    : "border-primary bg-muted",
                )}
              >
                <p
                  className={cn(
                    "text-xs font-medium",
                    self ? "text-primary-foreground/90" : "text-primary",
                  )}
                >
                  {message.replyTo.author}
                </p>
                <p
                  className={cn(
                    "line-clamp-1 text-xs",
                    self ? "text-primary-foreground/80" : "text-muted-foreground",
                  )}
                >
                  {message.replyTo.text}
                </p>
              </div>
            )}
            <p className="whitespace-pre-wrap leading-relaxed">{message.text}</p>
            <span
              className={cn(
                "mt-0.5 block text-right text-[10px]",
                self ? "text-primary-foreground/70" : "text-muted-foreground",
              )}
            >
              {message.time}
            </span>
          </div>
        </div>

        {/* reactions */}
        {message.reactions && message.reactions.length > 0 && (
          <div className="flex flex-wrap gap-1">
            {message.reactions.map((r) => (
              <button
                key={r.emoji}
                onClick={() => onReact(r.emoji)}
                className={cn(
                  "flex items-center gap-1 rounded-full border px-2 py-0.5 text-xs transition-colors",
                  r.reacted
                    ? "border-primary/40 bg-primary/10 text-primary"
                    : "border-border bg-muted/60 text-muted-foreground hover:bg-muted",
                )}
              >
                <span>{r.emoji}</span>
                <span>{r.count}</span>
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
