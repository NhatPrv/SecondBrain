import { AppShell } from "@/components/app-shell"
import { Messenger } from "@/components/messenger/messenger"
import { conversations } from "@/lib/messenger-data"

export default function FamilyChatPage() {
  return (
    <AppShell title="Family Chat" noScroll>
      <Messenger conversations={conversations} heading="Conversations" />
    </AppShell>
  )
}
