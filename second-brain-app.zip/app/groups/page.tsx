import { AppShell } from "@/components/app-shell"
import { Messenger } from "@/components/messenger/messenger"
import { groupConversations } from "@/lib/messenger-data"

export default function GroupsPage() {
  return (
    <AppShell title="Groups" noScroll>
      <Messenger conversations={groupConversations} heading="Group chats" />
    </AppShell>
  )
}
