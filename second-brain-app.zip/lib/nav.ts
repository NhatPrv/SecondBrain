import type { LucideIcon } from "lucide-react"
import {
  Home,
  MessageCircle,
  Users,
  UsersRound,
  FolderClosed,
  StickyNote,
  Pin,
  Trash2,
  Settings,
} from "lucide-react"

export type NavItem = {
  title: string
  href: string
  icon: LucideIcon
  badge?: number
}

export const mainNav: NavItem[] = [
  { title: "Home", href: "/", icon: Home },
  { title: "Self Chat", href: "/self-chat", icon: MessageCircle },
  { title: "Family Chat", href: "/family-chat", icon: Users, badge: 3 },
  { title: "Groups", href: "/groups", icon: UsersRound },
  { title: "Files", href: "/files", icon: FolderClosed },
  { title: "Notes", href: "/notes", icon: StickyNote },
]

export const libraryNav: NavItem[] = [
  { title: "Pinned", href: "/pinned", icon: Pin },
  { title: "Trash", href: "/trash", icon: Trash2 },
  { title: "Settings", href: "/settings", icon: Settings },
]
